package ai.rubik.app.entity.dto;

public class SequenceDTO {

	private Integer sequenceNumber;
	private String jobName;
	private String jobQueryName;

	public Integer getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Integer sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobQueryName() {
		return jobQueryName;
	}

	public void setJobQueryName(String jobQueryName) {
		this.jobQueryName = jobQueryName;
	}

	@Override
	public String toString() {
		return "SequenceDTO [sequenceNumber=" + sequenceNumber + ", jobName=" + jobName + ", jobQueryName="
				+ jobQueryName + "]";
	}
}
