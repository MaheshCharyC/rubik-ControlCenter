package ai.rubik.app.entity.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import ai.rubik.app.entity.dto.SequenceDTO;

public class SequenceMapper implements RowMapper<SequenceDTO>{

	@Override
	public SequenceDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		 SequenceDTO sequenceDTO = new SequenceDTO();
		 sequenceDTO.setJobName(rs.getString("edp_job_name"));
		 sequenceDTO.setJobQueryName(rs.getString("name"));
		 sequenceDTO.setSequenceNumber(rs.getInt("sequence_number"));
		return sequenceDTO;
	}

}
