package ai.rubik.app.entity.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import ai.rubik.app.entity.JobDetail;

public class JobDetailRowMapper implements RowMapper<JobDetail> {

	@Override
	public JobDetail mapRow(ResultSet row, int rowNum) throws SQLException {
		JobDetail jobdetail = new JobDetail();
		jobdetail.setCurrentStatus(row.getString("status"));
		jobdetail.setProcessedRowsPerSecond(row.getFloat("processed_rows_per_second"));
		jobdetail.setTotalTask(row.getInt("total_task"));
		jobdetail.setCompletedTask(row.getInt("completed_task"));
		jobdetail.setKilledTask(row.getInt("killed_tasks"));
		jobdetail.setFailedTask(row.getInt("failed_tasks"));
		jobdetail.setActiveTask(row.getInt("active_tasks"));
		jobdetail.setMemoryUsed(row.getBigDecimal("memory_used"));
		jobdetail.setTotalRows(row.getInt("total_number_of_rows"));
		jobdetail.setInputRows(row.getInt("input_rows"));
		jobdetail.setInputRowsPerSecond(row.getFloat("input_rows_per_second"));
		jobdetail.setJobStartTime(row.getString("job_start_time"));
		jobdetail.setJobCompletionTime(row.getString("job_completion_time"));
		jobdetail.setInputBytes(row.getInt("input_bytes"));
		jobdetail.setOutputBytes(row.getInt("output_bytes"));

		return jobdetail;
	}

}
