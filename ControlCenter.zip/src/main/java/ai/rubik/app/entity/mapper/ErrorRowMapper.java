package ai.rubik.app.entity.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import ai.rubik.app.entity.JobError;

public class ErrorRowMapper implements RowMapper<JobError> {
	@Override
	public JobError mapRow(ResultSet row, int rowNum) throws SQLException {
		JobError err = new JobError();
		err.setErrorCode(row.getString("rule_cd"));
		err.setCount(row.getInt("count"));
		
		return err;
	}
}
