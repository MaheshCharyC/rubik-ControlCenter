package ai.rubik.app.entity;

import java.math.BigDecimal;

public class JobDetail {
//	private int jobId;
	private String currentStatus;
	private float processedRowsPerSecond;
	private int totalTask;
	private int completedTask;
	private int killedTask;
	private int failedTask;
	private int activeTask;
	private BigDecimal memoryUsed;
	private int totalRows;
	private int inputRows;
	private float inputRowsPerSecond;
	private int inputBytes;
	private int outputBytes;
	private String jobStartTime;
	private String jobCompletionTime;

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	public float getProcessedRowsPerSecond() {
		return processedRowsPerSecond;
	}

	public void setProcessedRowsPerSecond(float processedRowsPerSecond) {
		this.processedRowsPerSecond = processedRowsPerSecond;
	}

	public int getTotalTask() {
		return totalTask;
	}

	public void setTotalTask(int totalTask) {
		this.totalTask = totalTask;
	}

	public int getCompletedTask() {
		return completedTask;
	}

	public void setCompletedTask(int completedTask) {
		this.completedTask = completedTask;
	}

	public int getKilledTask() {
		return killedTask;
	}

	public void setKilledTask(int killedTask) {
		this.killedTask = killedTask;
	}

	public int getFailedTask() {
		return failedTask;
	}

	public void setFailedTask(int failedTask) {
		this.failedTask = failedTask;
	}

	public int getActiveTask() {
		return activeTask;
	}

	public void setActiveTask(int activeTask) {
		this.activeTask = activeTask;
	}

	public BigDecimal getMemoryUsed() {
		return memoryUsed;
	}

	public void setMemoryUsed(BigDecimal memoryUsed) {
		this.memoryUsed = memoryUsed;
	}

	public int getTotalRows() {
		return totalRows;
	}

	public void setTotalRows(int totalRows) {
		this.totalRows = totalRows;
	}

	public int getInputRows() {
		return inputRows;
	}

	public void setInputRows(int inputRows) {
		this.inputRows = inputRows;
	}

	public float getInputRowsPerSecond() {
		return inputRowsPerSecond;
	}

	public void setInputRowsPerSecond(float inputRowsPerSecond) {
		this.inputRowsPerSecond = inputRowsPerSecond;
	}

	public String getJobStartTime() {
		return jobStartTime;
	}

	public void setJobStartTime(String jobStartTime) {
		this.jobStartTime = jobStartTime;
	}

	public String getJobCompletionTime() {
		return jobCompletionTime;
	}

	public void setJobCompletionTime(String jobCompletionTime) {
		this.jobCompletionTime = jobCompletionTime;
	}

	public int getInputBytes() {
		return inputBytes;
	}

	public void setInputBytes(int inputBytes) {
		this.inputBytes = inputBytes;
	}

	public int getOutputBytes() {
		return outputBytes;
	}

	public void setOutputBytes(int outputBytes) {
		this.outputBytes = outputBytes;
	}
}