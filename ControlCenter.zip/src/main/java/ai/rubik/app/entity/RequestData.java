package ai.rubik.app.entity;

import java.util.Date;

import javax.validation.constraints.NotNull;

public class RequestData {

//	@PastOrPresent(message = "StartDate cannot be future")
	@NotNull(message = "StartDate cannot be null")
	private Date startDate;

//	@PastOrPresent(message = "EndDate cannot be future")
	@NotNull(message = "EndDate cannot be null")
	private Date endDate;

	private String type;
	
    @NotNull(message = "Job name cannot be null")
    private String jobName;
    
    private long epochStartTime;

	private long epochEndTime;

	private long oneDayInMillis = 24 * 60 * 60 * 1000;
	
	public long getEpochStartTime() {
		return epochStartTime;
	}

	public long getEpochEndTime() {
		return epochEndTime;
	} 	
  	
	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		// Converting request start date to dot of the day(i.e. 00:00) in epoch time.
		this.epochStartTime = (startDate.getTime() / oneDayInMillis * oneDayInMillis) / 1000;
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		// Converting request end date to end of the day(i.e. 23:59) in epoch time.
		this.epochEndTime = ((endDate.getTime() / oneDayInMillis + 1) * oneDayInMillis - 1) / 1000;
		this.endDate = endDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
