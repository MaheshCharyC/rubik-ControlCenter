package ai.rubik.app.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import ai.rubik.app.entity.JobDetail;
import ai.rubik.app.entity.JobError;
import ai.rubik.app.entity.RequestData;
import ai.rubik.app.entity.dto.SequenceDTO;
import ai.rubik.app.service.IJobDetailService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Controller
public class JobDetailController {

	private static final Logger logger = LoggerFactory.getLogger(JobDetailController.class);
	
	@Autowired
	private IJobDetailService jobDetailService;

	@GetMapping("/dashboard")
	public String index(Model model) {

		List<SequenceDTO> sequenceDTOs = jobDetailService.getSequenceNumberForJob();
		Map<String, JobDetail> jobQuerySequenceMap = new HashMap<String, JobDetail>();
		Map<String, List<JobError>> jobErrorMap = new HashMap<String, List<JobError>>();
		sequenceDTOs.forEach(dto -> {
			if (!(dto.getJobName().equalsIgnoreCase("amperity_job")
					|| dto.getJobName().equalsIgnoreCase("tealium_historical_job"))) {
				if (dto.getJobQueryName().equalsIgnoreCase("processed_events")
						|| dto.getJobQueryName().equalsIgnoreCase("query_kafka")) {
					JobDetail jobDetail = jobDetailService.getStreamJobDetail(dto.getJobName(), dto.getJobQueryName(),
							dto.getSequenceNumber());
					jobQuerySequenceMap.put(dto.getJobName() + "_" + dto.getJobQueryName(), jobDetail);
				}
			} else {
				JobDetail jobDetail = jobDetailService.getBatchJobDetail(dto.getJobName(), dto.getSequenceNumber());
				jobQuerySequenceMap.put(dto.getJobName(), jobDetail);
			}
			if (StringUtils.isEmpty(jobErrorMap.get(dto.getJobName()))) {
				List<JobError> errors = jobDetailService.getAllErrors(dto.getJobName());
				jobErrorMap.put(dto.getJobName(), errors);
			}
		});


		model.addAttribute("tealiumRealtime", jobQuerySequenceMap.get("tealium_realtime_job_processed_events"));
		model.addAttribute("tealiumRealtimeErrors", jobErrorMap.get("tealium_realtime_job"));

		model.addAttribute("tealiumHistorical", jobQuerySequenceMap.get("tealium_historical_job"));
		model.addAttribute("tealiumHistoricalErrors", jobErrorMap.get("tealium_historical_job"));

		model.addAttribute("tealiumEhTokafka", jobQuerySequenceMap.get("tealium_eventhub_to_kafka_job_query_kafka"));
		model.addAttribute("tealiumEhKafkaErrors", jobErrorMap.get("tealium_eventhub_to_kafka_job"));

		model.addAttribute("amperity", jobQuerySequenceMap.get("amperity_job"));
		model.addAttribute("amperityErrors", jobErrorMap.get("amperity_job"));

		model.addAttribute("store", jobQuerySequenceMap.get("pos_job_processed_events"));
		model.addAttribute("posRealtimeErrors", jobErrorMap.get("pos_job"));

		model.addAttribute("order", jobQuerySequenceMap.get("oms_order_job_processed_events"));
		model.addAttribute("omsOrderErrors", jobErrorMap.get("oms_order_job"));

		model.addAttribute("release", jobQuerySequenceMap.get("oms_release_job_processed_events"));
		model.addAttribute("omsReleaseErrors", jobErrorMap.get("oms_release_job"));

		return "index";
	}

	
	@SuppressWarnings("serial")
	@GetMapping("/getJobs")
	@ResponseBody
	public HashMap<String, Object> getJobs() {
		try {
			return jobDetailService.getJobs();
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new HashMap<String, Object>() {
				{
					put("error", "Internal Server Error");
					put("message", e.getMessage());
					put("errorCode", 500);
				}
			};
		}
	}
	
	@SuppressWarnings("serial")
	@PostMapping("/getStreamData")
	@ResponseBody
	public HashMap<String, Object> getStreamData(@Valid @RequestBody RequestData req) {
		try {
			return jobDetailService.getStreamData(req);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new HashMap<String, Object>() {
				{
					put("error", "Internal Server Error");
					put("message", e.getMessage());
					put("errorCode", 500);
				}
			};
		}
	}

	@SuppressWarnings("serial")
	@PostMapping("/getBatchData")
	@ResponseBody
	public HashMap<String, Object> getBatchData(@Valid @RequestBody RequestData req) {
		try {
			return jobDetailService.getBatchData(req);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			return new HashMap<String, Object>() {
				{
					put("error", "Internal Server Error");
					put("message", e.getMessage());
					put("errorCode", "500");
				}
			};
		}
	}

}