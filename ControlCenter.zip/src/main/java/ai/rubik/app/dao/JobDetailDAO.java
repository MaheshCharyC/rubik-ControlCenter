package ai.rubik.app.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import ai.rubik.app.entity.JobDetail;
import ai.rubik.app.entity.JobError;
import ai.rubik.app.entity.RequestData;
import ai.rubik.app.entity.dto.SequenceDTO;
import ai.rubik.app.entity.mapper.ErrorRowMapper;
import ai.rubik.app.entity.mapper.JobDetailRowMapper;
import ai.rubik.app.entity.mapper.SequenceMapper;

@Transactional
@Repository
public class JobDetailDAO implements IJobDetailDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final TimeZone UTC_ZONE = TimeZone.getTimeZone("UTC");

	private static final Logger logger = LoggerFactory.getLogger(JobDetailDAO.class);

	@Value("${last.updated.time.stream}")
	private Integer lastUpdatedTimeStream;
	
	@Value("${last.updated.time.batch}")
	private Integer lastUpdatedTimeBatch;
	
	/**
	 * Query fetches the top 1 record of the stream data, to know recent activity / current status 
	 * - 'uptime' is calculated with the time difference of the job_start_time to current system time
	 * - 'status' is considered as 'ACTIVE' if is_enabled is true i.e, 1, else if the updated_at is more than 
	 * 		[specified time in properties, default is 5] mins then status is considered as 'STOPPED' if not 'COMPLETED'
	 * - 'input_rows_per_seconds' is fetched as ingestion_per_sec (Changes name because the previously it was named as such, and in-order to make API stable)
	 * - 'processed_rows_per_second' is fetched as processed_per_sec (Changes name because the previously it was named as such, and in-order to make API stable)
	 * - 'job_start_time' is the straight field
	 * - 'updated_at' is fetched as 'job_completion_time'
	 * - 'failed_reason' Currently this column does not exists for stream data, so sending a constant value 'UNKNOWN' in all cases
	 */
	String streamJobDetailsSql = "SELECT\r\n" + 
			"	TOP 1\r\n" + 
			"    (DATEDIFF(SECOND, '19700101', sysutcdatetime()) - job_start_time) AS 'uptime',\r\n" + 
			"	 IIF(is_enabled = 1, 'ACTIVE', IIF(DATEDIFF(SECOND, '19700101', sysutcdatetime()) - updated_at > (? * 60), 'STOPPED', 'COMPLETED') ) AS 'status',\r\n" + 
			"    ISNULL(input_rows_per_second, 0) AS 'ingestion_per_sec',\r\n" + 
			"    processed_rows_per_second AS 'processed_per_sec',\r\n" + 
			"    job_start_time AS 'job_start_time',\r\n" + 
			"	 updated_at AS 'job_completion_time',\r\n" + 
			"	 'UNKNOWN' AS 'failed_reason'\r\n" + 
			"FROM\r\n" + 
			"    edp_spark_stream_job_status\r\n" + 
			"WHERE \r\n" + 
			"	edp_job_name = ?\r\n" + 
			"ORDER BY date DESC, hour DESC ";

	/**
	 * Query fetches list items grouped by updated_at column, to plot graph with-in the requested time period 
	 * - 'ingestion_per_sec' Average is calculated on the sum of 'input_rows_per_second' grouped items by number of rows items grouped
	 * - 'processed_per_sec' Average is calculated on the sum of 'processed_rows_per_second' grouped items by number of rows items grouped
	 * - 'updated_at' is the straight field here
	 */
	String streamGraphDataSql = "SELECT \r\n" + 
			"    SUM(input_rows_per_second) / COUNT(*) AS 'ingestion_per_sec',\r\n" + 
			"    SUM(processed_rows_per_second) / COUNT(*) AS 'processed_per_sec',\r\n" + 
			"    updated_at \r\n" + 
			"FROM edp_spark_stream_job_status\r\n" + 
			"WHERE \r\n" + 
			"	edp_job_name = ?\r\n" + 
			"	AND updated_at BETWEEN ? AND ?\r\n" + 
			"GROUP BY \r\n" + 
			"	updated_at \r\n" + 
			"ORDER BY updated_at DESC ";
	
	/**
	 * Query fetches top 1 record of batch details, to know recent activity / current status
	 * - 'status' if the last updated_at is older than [specified time in properties, default is 5] mins and is_enabled is true then status is considered as 'Completed' 
	 * - 'events_processed' is the output_records_written
	 * - 'job_start_time' is the straight field
	 * - 'job_completion_time' we are considering 'updated_at' time as job_completion_time as the row is updated every-time
	 * - 'time_taken' is the difference of job_start_time to updated_at
	 * - 'failed_reason' is a straight field
	 */
	String batchJobDetailsSql = "SELECT   \r\n" + 
			"    TOP 1\r\n" + 
			"    IIF(DATEDIFF(SECOND, '19700101', sysutcdatetime()) - updated_at > (? * 60) , IIF(is_enabled = 1, 'COMPLETED', 'STOPPED'), 'ACTIVE') AS  'status',\r\n" + 
			"    output_records_written AS 'events_processed',\r\n" +
			"    job_start_time AS 'job_start_time',\r\n" + 
			"	 updated_at AS 'job_completion_time',\r\n" +  
			"    updated_at - job_start_time AS 'time_taken',\r\n" + 
			"    failed_reason\r\n" + 
			"FROM edp_spark_batch_job_status \r\n" + 
			"WHERE edp_job_name = ? \r\n" + 
			"    ORDER  BY job_start_time DESC\r\n";

	/**
	 * Query fetches list items to plot the batch graph grouped by date, job_start_time and updated_at column, 
	 * 	to SUM 'output_records_written' and 'time_taken' to process those records. 
	 * 	Above this in-order to get SUM of events per day there applied grouping on date which gives 
	 *  SUM of events processed on a day with the SUM of time_taken respectively. (Double grouping is applied to accurate the 'time_taken')
	 * - 'events' SUM of 'output_records_written' of the day
	 * - 'date' is a straight field to specify date of the data 
	 * - 'duration' is the SUM of difference between job_start_time and updated_at 
	 */
	String batchGraphDataSql = "SELECT SUM(events) AS 'events', date, SUM(duration) AS 'duration' FROM (\r\n" + 
			"    SELECT   \r\n" + 
			"        SUM(output_records_written) AS 'events',   \r\n" + 
			"        MAX(date) AS 'date',\r\n" + 
			"        updated_at - job_start_time AS 'duration'   \r\n" + 
			"    FROM edp_spark_batch_job_status \r\n" + 
			"    WHERE edp_job_name = ? \r\n" + 
			"        AND date BETWEEN ? AND ?  \r\n" + 
			"    GROUP BY [date], job_start_time, updated_at\r\n" + 
			") AS batch_jobs\r\n" + 
			"GROUP BY date ORDER BY date ASC";

	@Override
	public JobDetail getStreamJobDetail(String jobName, String eventName, Integer sequenceNumber) {
		String sql = "SELECT TOP 1 *  FROM edp_spark_job_status WHERE edp_job_name = ? and name = ? and seq =? ORDER BY created_at desc";
		RowMapper<JobDetail> rowMapper = new JobDetailRowMapper();
		JobDetail jobdetail = jdbcTemplate.queryForObject(sql, rowMapper, jobName, eventName, sequenceNumber);
		return jobdetail;
	}

	@Override
	public JobDetail getBatchJobDetail(String jobName, Integer sequenceNumber) {
		String sql = "SELECT TOP 1 *  FROM edp_spark_job_status WHERE edp_job_name = ? and seq = ? ORDER BY  created_at desc";
		RowMapper<JobDetail> rowMapper = new JobDetailRowMapper();
		JobDetail jobdetail = jdbcTemplate.queryForObject(sql, rowMapper, jobName, sequenceNumber);
		return jobdetail;
	}

	@Override
	public List<JobError> getAllErrors(String jobName) {
		Date date = new Date();
		Calendar c = Calendar.getInstance(UTC_ZONE);
		c.setTime(date);
		int year = c.get(Calendar.YEAR);
		int month = c.get(Calendar.MONTH) + 1;
		int dayOfMonth = c.get(Calendar.DAY_OF_MONTH);
		int hour = c.get(Calendar.HOUR_OF_DAY);
		String sql = "select rule_cd, count from edp_errors where job_name= ? and year = ? and month = ? and day = ? and hour = ?";
		RowMapper<ai.rubik.app.entity.JobError> rowMapper = new ErrorRowMapper();
		return this.jdbcTemplate.query(sql, rowMapper, jobName, year, month, dayOfMonth, hour);
	}

	@Override
	public List<SequenceDTO> getSequenceNumberForJob() {
		String sql = "SELECT  MAX(seq) as sequence_number,edp_job_name , name FROM edp_spark_job_status GROUP BY edp_job_name, name ";
		RowMapper<SequenceDTO> rowMapper = new SequenceMapper();
		return jdbcTemplate.query(sql, rowMapper);
	}

	/**
	 *  Fetches the current/recent stream run details and graph data within the selected time period (in days)
	 */
	@Override
	public HashMap<String, Object> getStreamData(RequestData req) throws Exception {
		long startTime = new Date().getTime();
		HashMap<String, Object> res = new HashMap<String, Object>();
		Map<String, Object> eventsThroughPutData = null;
		String uptime = "";
		if(lastUpdatedTimeStream == null) lastUpdatedTimeStream = 5;
		try {
			eventsThroughPutData = jdbcTemplate.queryForMap(streamJobDetailsSql,
					new Object[] { lastUpdatedTimeStream, req.getJobName() });
			int seconds = Integer.parseInt(eventsThroughPutData.get("uptime").toString());
			// If the job is still stopped manually we cannot get the uptime therefore this status condition.
			if (seconds > 0 && eventsThroughPutData.get("status").equals("ACTIVE")) {
				uptime = seconds + "";
				eventsThroughPutData.put("job_completion_time", "");
			} else
				uptime = "NA";
			eventsThroughPutData.put("uptime", uptime);
		} catch (EmptyResultDataAccessException e) {
			eventsThroughPutData = new HashMap<String, Object>();
		}
		res.put("events_throughput", eventsThroughPutData);
		List<Map<String, Object>> streamGraphData = jdbcTemplate.queryForList(streamGraphDataSql,
				new Object[] { req.getJobName(), req.getEpochStartTime(), req.getEpochEndTime() });
		res.put("events_processed", streamGraphData);
		long endTime = new Date().getTime();
		logger.info("Execution time taken to get Stream Data is: '"
				+ TimeUnit.MILLISECONDS.toMillis(endTime - startTime) + "' Milliseconds");
		return res;
	}

	/**
	 * Fetches the current/recent batch run details and graph data within the selected time period (in days)
	 */
	@Override
	public HashMap<String, Object> getBatchData(RequestData req) throws Exception {
		long startTime = new Date().getTime();
		HashMap<String, Object> res = new HashMap<String, Object>();
		Map<String, Object> batchJobDetails = null;
		if(lastUpdatedTimeBatch == null) lastUpdatedTimeBatch = 5;
		try {
			batchJobDetails = jdbcTemplate.queryForMap(batchJobDetailsSql,
					new Object[] { lastUpdatedTimeBatch, req.getJobName() });
			if (batchJobDetails.get("status").equals("ACTIVE"))
				batchJobDetails.put("job_completion_time", "");
		} catch (EmptyResultDataAccessException e) {
			batchJobDetails = new HashMap<String, Object>();
		}
		res.put("batch_job_details", batchJobDetails);
		List<Map<String, Object>> batchGraphData = jdbcTemplate.queryForList(batchGraphDataSql,
				new Object[] { req.getJobName(), req.getStartDate(), req.getEndDate() });
		res.put("events_processed", batchGraphData);
		long endTime = new Date().getTime();
		logger.info("Execution time taken to get Batch Data is: '" + TimeUnit.MILLISECONDS.toMillis(endTime - startTime)
				+ "' Milliseconds");
		return res;
	}

	/**
	 * Fetches the jobs meta data which are enabled
	 */
	@Override
	public HashMap<String, Object> getJobs() throws Exception {
		long startTime = new Date().getTime();
		String sql = "SELECT name, code, type FROM edp_job_names WHERE is_enabled = 1 ORDER BY id ASC";
		HashMap<String, Object> res = new HashMap<String, Object>();
		res.put("applications", jdbcTemplate.queryForList(sql));
		long endTime = new Date().getTime();
		logger.info("Execution time taken to get Jobs is: '" + TimeUnit.MILLISECONDS.toMillis(endTime - startTime)
				+ "' Milliseconds");
		return res;
	}
}
