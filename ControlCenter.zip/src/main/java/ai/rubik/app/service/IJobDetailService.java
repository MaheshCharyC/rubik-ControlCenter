package ai.rubik.app.service;

import java.util.HashMap;
import java.util.List;

import ai.rubik.app.entity.JobDetail;
import ai.rubik.app.entity.JobError;
import ai.rubik.app.entity.RequestData;
import ai.rubik.app.entity.dto.SequenceDTO;

public interface IJobDetailService {
	List<JobError> getAllErrors(String jobName);

	JobDetail getStreamJobDetail(String jobName, String eventName, Integer sequenceNumber);

	JobDetail getBatchJobDetail(String jobName, Integer sequenceNumber);

	List<SequenceDTO> getSequenceNumberForJob();

	HashMap<String, Object> getBatchData(RequestData req) throws Exception;

	HashMap<String, Object> getStreamData(RequestData req) throws Exception;

	HashMap<String, Object> getJobs() throws Exception;	
}
