package ai.rubik.app.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import ai.rubik.app.dao.IJobDetailDAO;
import ai.rubik.app.entity.JobDetail;
import ai.rubik.app.entity.JobError;
import ai.rubik.app.entity.RequestData;
import ai.rubik.app.entity.dto.SequenceDTO;

@Service
public class JobDetailService implements IJobDetailService {

	@Autowired
	private IJobDetailDAO jobDetailDAO;

	@Override
	public JobDetail getStreamJobDetail(String jobName, String eventName, Integer sequenceNumber) {
		JobDetail obj = jobDetailDAO.getStreamJobDetail(jobName, eventName, sequenceNumber);
		return obj;
	}

	@Override
	public JobDetail getBatchJobDetail(String jobName, Integer sequenceNumber) {
		JobDetail obj = jobDetailDAO.getBatchJobDetail(jobName, sequenceNumber);
		return obj;
	}

	@Override
	public List<JobError> getAllErrors(String jobName) {
		return jobDetailDAO.getAllErrors(jobName);
	}

	@Override
	public List<SequenceDTO> getSequenceNumberForJob() {
		return jobDetailDAO.getSequenceNumberForJob();
	}

	@Override
	public HashMap<String, Object> getBatchData(RequestData req) throws Exception {
		return jobDetailDAO.getBatchData(req);
	}

	@Override
	public HashMap<String, Object> getStreamData(RequestData req) throws Exception {
		return jobDetailDAO.getStreamData(req);
	}
	
	@Override
	@Cacheable("HashMap<String, Object>")
	public HashMap<String, Object> getJobs() throws Exception {
		return jobDetailDAO.getJobs();
	}
}
